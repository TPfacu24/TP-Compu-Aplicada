#!/bin/bash
# Directorios a respaldar
 DIRECTORIOS=("/root" "/etc" "/opt" "/var" "/www_dir" "/backup_dir")
 DESTINO="/backup_dir" 
 HOY=$(date +%Y%m%d)
 # Creación de backups individuales
for DIR in "${DIRECTORIOS[@]}"; do
   if [ -d "$DIR" ]; then
      NOMBRE_BACKUP=$(basename "$DIR")_bkp_${HOY}.tar.gz
      /bin/tar -cpzvf "$DESTINO/$NOMBRE_BACKUP" "$DIR"
      echo "Backup de $DIR completado en $DESTINO/$NOMBRE_BACKUP"
      echo "Backup de $DIR completado en $DESTINO/$NOMBRE_BACKUP" >> /var/log/bkp_all.log
   else
      echo "Error: El directorio $DIR no existe o no está montado."
      echo "Error al crear el backup, el día $HOY, el directorio de destino $DESTINO no existe o no está montado."     >> /var/log/bkp_all.log
   fi
done
